<?php

namespace models;

use PDO;

class Anggota
{
    protected static $table = 'anggota';

    protected static function connect()
    {
        return new PDO('mysql:host=localhost;dbname=koperasi_pegawai', 'root', '');
    }

    // READ - Get all
    public static function getAll()
    {
        $db = self::connect();
        $stmt = $db->query("SELECT * FROM " . self::$table);
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    // READ - Find by ID
    public static function find($id)
    {
        $db = self::connect();
        $stmt = $db->prepare("SELECT * FROM " . self::$table . " WHERE id = ?");
        $stmt->execute([$id]);
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }

    // CREATE
    public static function create($data)
    {
        $db = self::connect();
        $stmt = $db->prepare("
            INSERT INTO " . self::$table . " (status_aktif, pegawai_id, kartu_diskon_id)
            VALUES (?, ?, ?)
        ");
        return $stmt->execute([
            $data['status_aktif'],
            $data['pegawai_id'],
            $data['kartu_diskon_id']
        ]);
    }

    // UPDATE
    public static function update($id, $data)
    {
        $db = self::connect();
        $stmt = $db->prepare("
            UPDATE " . self::$table . " 
            SET status_aktif = ?, pegawai_id = ?, kartu_diskon_id = ?
            WHERE id = ?
        ");
        return $stmt->execute([
            $data['status_aktif'],
            $data['pegawai_id'],
            $data['kartu_diskon_id'],
            $id
        ]);
    }

    // DELETE
    public static function delete($id)
    {
        $db = self::connect();
        $stmt = $db->prepare("DELETE FROM " . self::$table . " WHERE id = ?");
        return $stmt->execute([$id]);
    }
}
